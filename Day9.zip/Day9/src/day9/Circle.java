/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package day9;

/**
 *
 * @author jkp
 */
public class Circle extends Shape{
    
    Circle(int x, int y){
        super(x,y);
    }

    @Override
    void draw() {
//        super.x = 10;
//        super.y = 20;
//        System.out.println(" x:" + super.x);
//        System.out.println(" y:" + super.y);
        
        System.out.println("Drawing circle at " +
                super.x +"and" + super.y);
    }
    
   // abstract void animate();
    
}
