/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package day9;

/**
 *
 * @author jkp
 */
public class Day9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Shape s1 = new Shape();
        
        Circle c1 = new Circle(30,40);
        c1.display();
        c1.draw();
        
    }
    
}

