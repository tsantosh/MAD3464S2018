/*
 * Author: Jigisha Patel
 * Purpose: Academic
 * 
 */
package day9;

/**
 *
 * @author jkp
 */
abstract class Shape {
    int x;
    int y;
    final int z = 0;
    
    Shape(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    void display(){
        System.out.println("This is to display shape");
    }
    
    abstract void draw();
}
