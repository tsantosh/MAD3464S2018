/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author macstudent
 */
public class FirstThread extends Thread{
    
    public FirstThread(){
        super("first thread");
        System.out.println("first thread created");
        start();
    }
    public void run(){
       try {
        for (int i=0; i<=5; i++){
            System.out.println("i"  + i);
            Thread.sleep(1000);
        }
    }
      catch(InterruptedException ex){
          ex.printStackTrace();
      }
       catch(Exception e) {
           e.printStackTrace();
       }
       finally {
           System.out.println("first thread created");
       }
    
    }

}