/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author macstudent
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       try { 
        Thread t1 = Thread.currentThread();
        System.out.println("Current thread" + t1);
        t1.setPriority(8);
           
        t1.setName("My thread");
        System.out.println("thread info"  + t1);
        System.out.println("is alive"  + t1.isAlive());
        System.out.println("deamon"  + t1.isDaemon());
        System.out.println("interuppted"  + t1.isInterrupted());
        for (int i=0; i<5; i++){
            
       
            
            
            System.out.println("i"  + i);
            
            new FirstThread();
            new SecondThread("SEcond thread");
            
            
            Thread.sleep(1000);
                    
        }
       }
       catch (InterruptedException ex){
           ex.printStackTrace();
       }
       catch(Exception ex){
           ex.printStackTrace();
       }
       
        // TODO code application logic here
    }
    
}
