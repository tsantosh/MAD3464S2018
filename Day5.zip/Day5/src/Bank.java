/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Bank {
    
    
    
    public static void main(String[] args)  {
        
        String Bankname;
        int BankId;
        
        
        
       
        
    
        
        
         BankAccount account1 = new BankAccount();
     System.out.println(account1.toString());
     
     BankAccount account2 = new BankAccount(1017 ,"gulmalia",2000.00);
     System.out.println(account2.toString());
        
    }

   
            
}
