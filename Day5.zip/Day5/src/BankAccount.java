
import static java.lang.System.in;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class BankAccount extends Bank{
    
    int accountnumber;
    String customerName;
    double balanceAmount;
    Scanner in = new Scanner(System.in);
    
    BankAccount(int accountnumber, String customerName, double balanceAmount){
        this.accountnumber = accountnumber;
        this.customerName = customerName;
        this.balanceAmount = balanceAmount;
        
    }

    BankAccount() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    void Setaccountnumber(){
        System.out.println("Enter bank account number");
        accountnumber = in.nextInt();
       
   
    }
    
    int Getaccountnumber(){
        
        return accountnumber;
        
    }
     void SetCustomername(){
         
        System.out.println("Enter customer name");
        customerName=in.nextLine();
        
        
    }
     
     String GetCustomername(){
         
       return customerName;
       
     }
     
     void SetBalanceAmount(){
         System.out.println("No available balance");
        balanceAmount = in.nextDouble();
         
     }
     double Getbalanceamount(){
         
         
         return balanceAmount;
     }
     
     @Override
   public String toString(){
       String data = "Account Number : " + accountnumber + "\n" +
               "Customer Name  : " + customerName + "\n" +
               "Balance Amount : " + balanceAmount + "\n" ;              
       
       return data;
   }
   
   void setData(){
       Setaccountnumber();
       SetCustomername();
       SetBalanceAmount();
   }
    
}
