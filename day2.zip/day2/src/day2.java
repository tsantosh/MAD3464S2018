/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class day2 {
        public static void main (String[] args){
            int i = 1;
            while (i<6){
                System.out.println("i:" +i);
                i++;
            }
            System.out.println("loop ended");
            
            
            i = 6;
            do {
                System.out.println("i:" + i);
                i++;
                            
            }while (i<6);
            
            for (i = 1; i<6; i++){
                System.out.println("i:" + i);
                
            }
            for (i = 1; i<6; i++){
                if(i==3){
                    continue;
                }
                System.out.println();
            }
            
            
            
        }
        
    
    
    
    
//    
//    public static void main (String[] args){
//        
//    for(int row=0; row<5; row++)
//    {
//        for(int space=5; space>row; space--)
//        {
//            System.out.print(" ");
//        }
//        for(int col=0; col<=row; col++)
//        {
//            System.out.print("* ");
//        }
//    }
//    
//  
//    }  
//    
    
    // forming a traingle //
//    public static void main (String[] args){
//        
//    for(int row=0; row<5; row++)
//    {
//        for(int space=5; space>row; space--)
//        {
//            System.out.print(" ");
//        }
//        for(int col=0; col<=row; col++)
//        {
//            System.out.print("* ");
//        }
//        System.out.println("");
//    }
//    
//  
//    }  
    
    
//stars upside down// 
    
//        public static void main (String[] args){
//        
//    for(int row=5; row>0; row--)
//    {
//        for(int space=5; space>row; space--)
//        {
//            System.out.print(" ");
//        }
//        for(int col=0; col<row; col++)
//        {
//            System.out.print("* ");
//        }
//        System.out.println("");
//    }
//    
//  
//    }  
    
    
    
    
    
}
