/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day6;

/**
 *
 * @author macstudent
 */
public class Day6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int n1= 10;
        int n2 =0;
        int numbers[]={10,20,20};
        
        try {
            int result = n1 / n2;
            result += numbers[6];
            System.out.println("result:" + result);
            
        }
        catch(ArithmeticException e){
            System.err.println("Cannot divide by zero");
            
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.err.println("array element not avilable");
            
        }
        catch(Exception e){
                System.err.println("something went wrong");
        }
        finally{
            System.out.println("This is a finally block");
        }
        // TODO code application logic here
        
        Addition add1 = new Addition();
        add1.display();
        add1.Multiplication();
    }

   
    
}
