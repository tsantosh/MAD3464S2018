package day6;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Addition extends Multiplication  implements arithmetic{
    @Override
    public void display (){
        
        System.out.println("the sum of two nuymbers is " + (n1 +n2));
        
    }
    public void Multiplication (){
        
        System.out.println("the sum of two nuymbers is " + (n1 * n2));
        
    }
}
