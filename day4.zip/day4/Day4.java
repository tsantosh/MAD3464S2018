/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4;

/**
 *
 * @author macstudent
 */
public class Day4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        person ishav = new person();
       // System.out.println(ishav.toString());
        
       person alay = new person ("alay","usa","123456",23,'m');
       // System.out.println(alay.toString());
        
        Employee emp1 = new Employee();
        emp1.name = "santosh";
        emp1.address ="kapra";
        emp1.age=1;
        emp1.gender='m';
        emp1.empId="c09";
        emp1.dept=20;
        emp1.joiningDate="02 november 2016";
        
        System.out.println(emp1.toString());
        
        Employee emp2 = new Employee("satyam","telangana","33554",21,'M',"p142",30,"13 may 2016");
        System.out.println(emp2.toString());
        
        // TODO code application logic here
    }
    
}
