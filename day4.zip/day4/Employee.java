/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day4;

/**
 *
 * @author macstudent
 */
public class Employee extends person {
    String empId;
    int dept;
    String joiningDate;
    
    Employee(){
        super();
        this.empId = "temp";
        this.dept = 0;
        this.joiningDate = "asdd";
        
    }

   Employee(String name, String address, String phoneNo,int age,char gender ,String empId,int dept,String JoiningDate ){
       this.empId =empId;
       this.dept = dept;
        this.joiningDate = joiningDate;
       
   }
    
    
    public String toString(){
        
        String PersonalDetails = super.toString();
        String data ="employee id :" + this.empId + "\n" + "department :" + this.dept + "\n" + "joining date :" + this.joiningDate;
        data = PersonalDetails + data;
        return data;
    }
    
}
